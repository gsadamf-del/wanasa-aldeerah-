"""${message}
Revision ID: ${up_revision}
Revises: ${down_revision | comma,n}
Create Date: ${create_date}
"""
from alembic import op
revision="${up_revision}"
down_revision=${repr(down_revision)}
branch_labels=${repr(branch_labels)}
depends_on=${repr(depends_on)}
def upgrade(): pass
def downgrade(): pass
