from logging.config import fileConfig
from pathlib import Path
import sys
from sqlalchemy import engine_from_config,pool
from alembic import context
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.core.config import settings
from app.db.session import Base
import app.models,app.models_v19,app.models_v20,app.models_v21,app.models_v22,app.models_v23,app.models_v24,app.models_v25
config=context.config
if config.config_file_name: fileConfig(config.config_file_name)
config.set_main_option("sqlalchemy.url",settings.database_url.replace("%","%%"))
target_metadata=Base.metadata
def run_migrations_offline():
 context.configure(url=settings.database_url,target_metadata=target_metadata,literal_binds=True,dialect_opts={"paramstyle":"named"},compare_type=True)
 with context.begin_transaction(): context.run_migrations()
def run_migrations_online():
 connectable=engine_from_config(config.get_section(config.config_ini_section,{}),prefix="sqlalchemy.",poolclass=pool.NullPool)
 with connectable.connect() as connection:
  context.configure(connection=connection,target_metadata=target_metadata,compare_type=True,compare_server_default=True)
  with context.begin_transaction(): context.run_migrations()
if context.is_offline_mode(): run_migrations_offline()
else: run_migrations_online()
